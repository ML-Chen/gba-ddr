/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 Bidoof Bidoof.png 
 * Time-stamp: Thursday 04/11/2019, 02:46:56
 * 
 * Image Information
 * -----------------
 * Bidoof.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BIDOOF_H
#define BIDOOF_H

extern const unsigned short Bidoof[38400];
#define BIDOOF_SIZE 76800
#define BIDOOF_LENGTH 38400
#define BIDOOF_WIDTH 240
#define BIDOOF_HEIGHT 160

#endif

