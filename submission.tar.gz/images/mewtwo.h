/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 mewtwo Mewtwo.png 
 * Time-stamp: Thursday 04/11/2019, 02:35:17
 * 
 * Image Information
 * -----------------
 * Mewtwo.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MEWTWO_H
#define MEWTWO_H

extern const unsigned short Mewtwo[38400];
#define MEWTWO_SIZE 76800
#define MEWTWO_LENGTH 38400
#define MEWTWO_WIDTH 240
#define MEWTWO_HEIGHT 160

#endif

