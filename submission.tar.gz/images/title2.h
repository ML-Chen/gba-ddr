/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 title2 title2.png 
 * Time-stamp: Thursday 04/11/2019, 03:27:13
 * 
 * Image Information
 * -----------------
 * title2.png 210@119
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLE2_H
#define TITLE2_H

extern const unsigned short title2[24990];
#define TITLE2_SIZE 49980
#define TITLE2_LENGTH 24990
#define TITLE2_WIDTH 210
#define TITLE2_HEIGHT 119

#endif

