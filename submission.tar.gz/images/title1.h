/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 title1 Title screen 1.png 
 * Time-stamp: Sunday 04/07/2019, 02:36:37
 * 
 * Image Information
 * -----------------
 * Title screen 1.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLE1_H
#define TITLE1_H

extern const unsigned short title1[38400];
#define TITLE1_SIZE 76800
#define TITLE1_LENGTH 38400
#define TITLE1_WIDTH 240
#define TITLE1_HEIGHT 160

#endif

