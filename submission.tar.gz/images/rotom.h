/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 rotom Rotom.png 
 * Time-stamp: Thursday 04/11/2019, 02:35:39
 * 
 * Image Information
 * -----------------
 * Rotom.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ROTOM_H
#define ROTOM_H

extern const unsigned short Rotom[38400];
#define ROTOM_SIZE 76800
#define ROTOM_LENGTH 38400
#define ROTOM_WIDTH 240
#define ROTOM_HEIGHT 160

#endif

