/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 Porygon-Z Porygon-Z.png 
 * Time-stamp: Thursday 04/11/2019, 02:45:16
 * 
 * Image Information
 * -----------------
 * Porygon-Z.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PORYGONZ_H
#define PORYGONZ_H

extern const unsigned short PorygonZ[38400];
#define PORYGONZ_SIZE 76800
#define PORYGONZ_LENGTH 38400
#define PORYGONZ_WIDTH 240
#define PORYGONZ_HEIGHT 160

#endif

